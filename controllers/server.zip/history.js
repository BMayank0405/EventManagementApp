const User = require("../models/user");
const Event = require("../models/event");
const { finduserById } = require("./findUser");
const { findVenueById } = require("./findVenue");

module.exports = {
  history: async (req, res, next) => {
    const { id } = req.user;

    //stat is used for checking which events were approved by previous faculty
    let stat = 1;
    let user = "facultyId";
    if (flag == 2) {
      stat = 2;
      user = "headId";
    }

    try {
      let eventHistory = await Event.find({
        $and: [
          {
            "date.startDate": {
              $gte: new Date()
            }
          },
          {
            [user]: id
          },
          {
            $or: [{ status: stat }, { status: -stat }]
          }
        ]
      });

      let returnEvent = [];
      let counter = 0;
      for (let event of eventHistory) {
        let society = await finduserById(event.societyId);
        returnEvent.push({});
        returnEvent[counter] = Object.assign({}, event)._doc;

        returnEvent[counter]["society"] = society.name;
        let venue = await findVenueById(event.venueId);
        returnEvent[counter]["venue"] = venue;

        counter++;
      }

      return res.status(200).json({ returnEvent });
    } catch (err) {
      if (err)
        return res.status(403).send({
          error: err.errmsg
        });
    }
  }
};
