const Event = require("../models/event");

module.exports = {
  SocietyEdit: async (req, res, next) => {
    const { id } = req.value.body;
    try {
      let update = await Event.findByIdAndUpdate(
        { _id: id },
        { $set: req.value.body },
        { new: true }
      );

      return res.status(200).json({ message: "Event successfully editted" });
    } catch (err) {
      if (err) return res.status(403).send({ error: err.errmsg });
    }
  }
};
