const Event = require("../models/event");

const { finduserById } = require("./findUser");
const { findVenueById } = require("./findVenue");

module.exports = {
  approve: async (req, res, next) => {
    const { id } = req.value.body;
    const { flag } = req.user;

    let user = "facultyId";
    let stat = 0;
    if (flag == 4) {
      stat = 1;
      user = "headId";
    }

    try {
      let valid = await Event.find(
        {
          $and: [
            { _id: id },
            { activeId: 1 },
            {
              [user]: req.user.id
            }
          ]
        },
        "status"
      );

      let validFaculty = valid ? true : false;

      if (!validFaculty)
        return res.status(403).send({ meassage: "not a valid faculty" });
      if (valid.status != stat)
        return res
          .status(403)
          .send({ meassage: "Event has already been approved or declined" });

      try {
        let event_obj = {};
        let update = await Event.findByIdAndUpdate(
          { _id: id },
          { $set: { status: 1 } },
          { new: true }
        );

        let society = await finduserById(update.societyId);

        let venue = await findVenueById(update.venueId);
        event_obj = Object.assign({}, update)._doc;
        event_obj["society"] = society.name;
        event_obj["venue"] = venue;

        return res.json({ event_obj });
      } catch (err) {
        if (err)
          return res.status(403).send({
            error: err.errmsg
          });
      }
    } catch (err) {
      if (err)
        return res.status(403).send({
          error: err.errmsg
        });
    }
  }
};
