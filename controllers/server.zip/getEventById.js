const Event = require("../models/event");
const { findVenueById } = require("./findVenue");

module.exports = {
  getEventById: async (req, res, next) => {
    let { id } = req.body;
    try {
      let event = await Event.findById({ _id: id });
      let society = await finduserById(event.societyId);
      returnEvent.push({});
      returnEvent[counter] = Object.assign({}, event)._doc;
      let venue = await findVenueById(event.venueId);
      returnEvent[counter]["venue"] = venue;
    } catch (err) {
      if (err)
        return res.status(403).send({
          error: err.errmsg
        });
    }
  }
};
